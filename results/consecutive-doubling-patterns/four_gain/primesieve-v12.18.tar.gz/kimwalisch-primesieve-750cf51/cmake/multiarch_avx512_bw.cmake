# Runtime dispatch selects AVX512 BW when supported by the CPU and OS,
# and uses the default algorithm otherwise. The kernels use target
# attributes with GCC/Clang (including clang-cl), and noinline with
# native MSVC.

include(CheckCXXSourceCompiles)
include(CMakePushCheckState)

cmake_push_check_state()
set(CMAKE_REQUIRED_INCLUDES
    "${PROJECT_SOURCE_DIR}"
    "${PROJECT_SOURCE_DIR}/include")

check_cxx_source_compiles("
    #include <primesieve/cpu_arch_macros.hpp>

    // Runtime dispatch for AVX512 is not needed if
    // the user compiles with -mavx512f -mavx512bw.
    // Runtime dispatch generally causes a minor
    // overhead, hence we disable it if it is not needed.
    #if defined(ENABLE_AVX512_BW)
      Error: AVX512BW multiarch not needed!
    #endif

    #include <include/primesieve/macros.hpp>
    #include <src/arch/x86/cpuid.cpp>
    #include <immintrin.h>
    #include <stdint.h>
    #include <cstddef>

    PRIMESIEVE_TARGET_ATTRIBUTE(\"avx512f,avx512bw\")
    void presieve1_x86_avx512(const uint8_t* __restrict preSieve0,
                              const uint8_t* __restrict preSieve1,
                              uint8_t* __restrict sieve,
                              std::size_t bytes)
    {
        std::size_t i = 0;

        for (; i + 64 <= bytes; i += sizeof(__m512i))
        {
            _mm512_storeu_epi8((__m512i*) &sieve[i],
                _mm512_and_si512(_mm512_loadu_epi8((const __m512i*) &preSieve0[i]), 
                                 _mm512_loadu_epi8((const __m512i*) &preSieve1[i])));
        }

        if (i < bytes)
        {
            __mmask64 mask = 0xffffffffffffffff >> (i + 64 - bytes);

            _mm512_mask_storeu_epi8((__m512i*) &sieve[i], mask,
                _mm512_and_si512(_mm512_maskz_loadu_epi8(mask, (const __m512i*) &preSieve0[i]), 
                                 _mm512_maskz_loadu_epi8(mask, (const __m512i*) &preSieve1[i])));
        }
    }

    void presieve1_default(const uint8_t* __restrict preSieved0,
                           const uint8_t* __restrict preSieved1,
                           uint8_t* __restrict sieve,
                           std::size_t bytes)
    {
        for (std::size_t i = 0; i < bytes; i++)
            sieve[i] = preSieved0[i] & preSieved1[i];
    }

    int main()
    {
        uint8_t sieve[10] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
        uint8_t PreSieveTable1[10] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
        uint8_t PreSieveTable2[10] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };

        if (primesieve::has_avx512_bw())
            presieve1_x86_avx512(&PreSieveTable1[0], &PreSieveTable2[0], &sieve[0], 10);
        else
            presieve1_default(&PreSieveTable1[0], &PreSieveTable2[0], &sieve[0], 10);

        return (sieve[0] == 0) ? 0 : 1;
    }
" PRIMESIEVE_MULTIARCH_AVX512_BW)

if(PRIMESIEVE_MULTIARCH_AVX512_BW)
    list(APPEND PRIMESIEVE_COMPILE_DEFINITIONS "ENABLE_MULTIARCH_AVX512_BW")
endif()

cmake_pop_check_state()
