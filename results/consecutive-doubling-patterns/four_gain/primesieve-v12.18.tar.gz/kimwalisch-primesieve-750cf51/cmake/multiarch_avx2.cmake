# Runtime dispatch selects AVX2 when supported by the CPU and OS,
# and uses the default algorithm otherwise. The kernels use target
# attributes with GCC/Clang (including clang-cl), and noinline with
# native MSVC.

include(CheckCXXSourceCompiles)
include(CMakePushCheckState)

cmake_push_check_state()
set(CMAKE_REQUIRED_INCLUDES
    "${PROJECT_SOURCE_DIR}"
    "${PROJECT_SOURCE_DIR}/include")

check_cxx_source_compiles("
    #include <primesieve/cpu_arch_macros.hpp>

    // Runtime dispatch for AVX2 is not needed if the compiler flags
    // already enable AVX2 with BMI2 and POPCNT, or the faster
    // AVX512 VBMI2 algorithm. Runtime dispatch generally causes
    // a minor overhead, hence we disable it if it is not needed.
    #if defined(ENABLE_AVX2_BMI2) || \
        defined(ENABLE_AVX512_VBMI2)
      Error: AVX2 multiarch not needed!
    #endif

    #include <include/primesieve/macros.hpp>
    #include <src/arch/x86/cpuid.cpp>
    #include <immintrin.h>
    #include <stdint.h>

    class PrimeGenerator {
    public:
        PRIMESIEVE_TARGET_ATTRIBUTE(\"avx2,bmi2,popcnt\")
        void fillNextPrimes_x86_avx2(uint64_t* primes64);
        void fillNextPrimes_default(uint64_t* primes64);
        void fillNextPrimes(uint64_t* primes64)
        {
            if (primesieve::has_avx2())
                fillNextPrimes_x86_avx2(primes64);
            else
                fillNextPrimes_default(primes64);
        }
    };

    void PrimeGenerator::fillNextPrimes_default(uint64_t* primes64)
    {
        primes64[0] = 2;
    }

    PRIMESIEVE_TARGET_ATTRIBUTE(\"avx2,bmi2,popcnt\")
    void PrimeGenerator::fillNextPrimes_x86_avx2(uint64_t* primes64)
    {
        alignas(16) uint16_t buffer[16] = { 7, 11, 13, 17, 19, 23, 29, 31 };
        uint64_t bits64 = primes64[0];
        uint64_t pos = _mm_popcnt_u64(_bzhi_u64(bits64, 8));
        __m128i offsets = _mm_set1_epi16(30);
        __m128i bitValues = _mm_load_si128((const __m128i*) buffer);
        _mm_storeu_si128((__m128i*) &buffer[pos], _mm_add_epi16(offsets, bitValues));
        __m256i base = _mm256_set1_epi64x(123);
        __m256i offsets64 = _mm256_cvtepu16_epi64(_mm_loadl_epi64((const __m128i*) buffer));
        _mm256_storeu_si256((__m256i*) primes64, _mm256_add_epi64(base, offsets64));
    }

    int main()
    {
        uint64_t primes[8] = { 0xff };
        PrimeGenerator p;
        p.fillNextPrimes(primes);
        return 0;
    }
" PRIMESIEVE_MULTIARCH_AVX2)

if(PRIMESIEVE_MULTIARCH_AVX2)
    list(APPEND PRIMESIEVE_COMPILE_DEFINITIONS "ENABLE_MULTIARCH_AVX2")
endif()

cmake_pop_check_state()
