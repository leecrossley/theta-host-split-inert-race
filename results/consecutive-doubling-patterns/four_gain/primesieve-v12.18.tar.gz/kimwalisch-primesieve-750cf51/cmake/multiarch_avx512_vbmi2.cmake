# Runtime dispatch selects AVX512 VBMI2 when supported by the CPU and OS,
# and uses the default algorithm otherwise. The kernels use target
# attributes with GCC/Clang (including clang-cl), and noinline with
# native MSVC.

include(CheckCXXSourceCompiles)
include(CMakePushCheckState)

cmake_push_check_state()
set(CMAKE_REQUIRED_INCLUDES
    "${PROJECT_SOURCE_DIR}"
    "${PROJECT_SOURCE_DIR}/include")

check_cxx_source_compiles("
    #include <primesieve/cpu_arch_macros.hpp>

    // Runtime dispatch for AVX512 is not needed if
    // the user compiles with -mavx512f -mavx512vbmi -mavx512vbmi2 -mpopcnt.
    // Runtime dispatch generally causes a minor
    // overhead, hence we disable it if it is not needed.
    #if defined(ENABLE_AVX512_VBMI2)
      Error: AVX512VBMI2 multiarch not needed!
    #endif

    #include <include/primesieve/macros.hpp>
    #include <src/arch/x86/cpuid.cpp>
    #include <immintrin.h>
    #include <stdint.h>

    class PrimeGenerator {
    public:
        PRIMESIEVE_TARGET_ATTRIBUTE(\"avx512f,avx512vbmi,avx512vbmi2,popcnt\")
        void fillNextPrimes_x86_avx512(uint64_t* primes64);
        void fillNextPrimes_default(uint64_t* primes64);
        void fillNextPrimes(uint64_t* primes64)
        {
            if (primesieve::has_avx512_vbmi2())
                fillNextPrimes_x86_avx512(primes64);
            else
                fillNextPrimes_default(primes64);
        }
    };

    void PrimeGenerator::fillNextPrimes_default(uint64_t* primes64)
    {
        primes64[0] = 2;
    }

    PRIMESIEVE_TARGET_ATTRIBUTE(\"avx512f,avx512vbmi,avx512vbmi2,popcnt\")
    void PrimeGenerator::fillNextPrimes_x86_avx512(uint64_t* primes64)
    {
        __m512i bytes_0_to_7 = _mm512_setr_epi64(0, 1, 2, 3, 4, 5, 6, 7);
        __m512i base = _mm512_set1_epi64(_mm_popcnt_u64(primes64[0]));
        __m512i bitValues = _mm512_maskz_compress_epi8(0xffff, base);
        __m512i vprimes = _mm512_maskz_permutexvar_epi8(0x0101010101010101, bytes_0_to_7, bitValues);
        vprimes = _mm512_add_epi64(base, vprimes);
        _mm512_storeu_si512(primes64, vprimes);
    }

    int main()
    {
        uint64_t primes[8] = { 0xffff };
        PrimeGenerator p;
        p.fillNextPrimes(primes);
        return 0;
    }
" PRIMESIEVE_MULTIARCH_AVX512_VBMI2)

if(PRIMESIEVE_MULTIARCH_AVX512_VBMI2)
    list(APPEND PRIMESIEVE_COMPILE_DEFINITIONS "ENABLE_MULTIARCH_AVX512_VBMI2")
endif()

cmake_pop_check_state()
